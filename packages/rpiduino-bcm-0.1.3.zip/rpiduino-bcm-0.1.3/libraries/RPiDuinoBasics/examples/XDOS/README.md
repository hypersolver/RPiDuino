# XDOS Arduino sketches

安裝 RPiDuino 0.1.3 後，Arduino IDE 的範例選單會提供 XDOS 草稿。
現有板卡的編譯和上傳配方會產生裸機 IMG。要在 XDOS 桌面執行這些
草稿，請使用配對的 XDOS WSL 建置和 XAPP 載入器。

| 草稿 | XDOS 功能 |
| --- | --- |
| XappBasic | 最小 setup / loop 範例 |
| XappBlink | 板載 ACT LED 和 LVGL 狀態 |
| XappLvgl | LVGL 點擊計數 |
| XappImageView | SD／USB 上的 BMP 顯示 |

在 RPiDuino 原始碼工作區執行以下命令，會編譯三個桌面樣本及配對
核心。在 WSL 執行，並使用專案既有 Circle 工具鏈。

    bash .wsl/arduino-sdk-test/build-files-tree.sh

XappBasic 可使用 XDOS 原始碼內的 XDOS_WIDGETS_SKETCH=XappBasic
建置選項。獨立燒錄測試可在 Arduino IDE 選 RPiDuino Basics → Blink，
該範例使用目前板卡的原生 IMG 配方。
